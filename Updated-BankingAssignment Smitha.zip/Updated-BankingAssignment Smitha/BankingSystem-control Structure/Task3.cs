﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace BankingSystem
//{
//    internal class Task3
//    {
//        static void Main(string[] args)
//        {
//            Console.Write("Enter number of customers: ");
//            int customers = int.Parse(Console.ReadLine());

//            for (int i = 1; i <= customers; i++)
//            {
//                Console.WriteLine("\nCustomer " + i + ":");

//                Console.Write("Enter initial balance: ");
//                double initialBalance = double.Parse(Console.ReadLine());

//                Console.Write("Enter annual interest rate (%): ");
//                double interestRate = double.Parse(Console.ReadLine());

//                Console.Write("Enter number of years: ");
//                int years = int.Parse(Console.ReadLine());

//                double futureBalance = initialBalance * Math.Pow((1 + interestRate / 100), years);

//                Console.WriteLine("Future balance after " + years + " years: $" + futureBalance);
//            }
//        }
//    }
//}
