﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace BankingSystem
//{
//    internal class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.Write("Enter customer's credit score: ");
//            int creditScore = int.Parse(Console.ReadLine());

//            Console.Write("Enter customer's annual income: ");
//            double income = double.Parse(Console.ReadLine());


//            if (creditScore > 700 && income >= 50000)
//            {
//                Console.WriteLine("Customer is eligible for a loan.");
//            }
//            else
//            {
//                Console.WriteLine("Customer is not eligible for a loan.");
//            }
//        }
//    }
//}

