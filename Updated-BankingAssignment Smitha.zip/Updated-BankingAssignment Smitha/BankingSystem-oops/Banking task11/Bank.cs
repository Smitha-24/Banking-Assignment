﻿using System;

public class Bank
{
    Account[] accounts = new Account[100];
    int count = 0;

    public void CreateAccount(Customer customer, string accType, float balance)
    {
        Account acc = null;

        if (accType == "Savings")
            acc = new SavingsAccount(balance, customer);
        else if (accType == "Current")
            acc = new CurrentAccount(balance, customer);
        else if (accType == "ZeroBalance")
            acc = new ZeroBalanceAccount(customer);

        if (acc != null)
        {
            accounts[count++] = acc;
            Console.WriteLine($"Account created successfully! Account No: {acc.AccountNumber}");
        }
    }

    public Account FindAccount(long accNo)
    {
        for (int i = 0; i < count; i++)
        {
            if (accounts[i].AccountNumber == accNo)
                return accounts[i];
        }
        Console.WriteLine("Account not found.");
        return null;
    }

    public void Deposit(long accNo, float amount)
    {
        Account acc = FindAccount(accNo);
        if (acc != null)
        {
            acc.AccountBalance += amount;
            Console.WriteLine("Deposit successful. New Balance: " + acc.AccountBalance);
        }
    }

    public void Withdraw(long accNo, float amount)
    {
        Account acc = FindAccount(accNo);
        if (acc != null)
        {
            acc.Withdraw(amount);
            Console.WriteLine("After Withdraw Balance: " + acc.AccountBalance);
        }
    }

    public void GetBalance(long accNo)
    {
        Account acc = FindAccount(accNo);
        if (acc != null)
            Console.WriteLine("Balance: " + acc.AccountBalance);
    }

    public void GetAccountDetails(long accNo)
    {
        Account acc = FindAccount(accNo);
        if (acc != null)
        {
            Console.WriteLine($"Account No: {acc.AccountNumber} | Type: {acc.AccountType} | Balance: {acc.AccountBalance}");
            acc.Customer.DisplayCustomer();
        }
    }

    public void CalculateInterest()
    {
        for (int i = 0; i < count; i++)
        {
            if (accounts[i] is SavingsAccount sa)
            {
                sa.CalculateInterest();
                Console.WriteLine($"Interest applied for Account No: {sa.AccountNumber}");
            }
        }
    }
}
