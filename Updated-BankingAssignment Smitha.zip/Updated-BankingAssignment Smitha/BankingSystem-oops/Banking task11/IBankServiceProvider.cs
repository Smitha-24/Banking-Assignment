﻿namespace service
{
    public interface IBankServiceProvider
    {
        void CreateAccount(Customer customer, string accType, float balance);
        void ListAccounts();
        void CalculateInterest();
    }
}
