﻿using System;
using System.Collections.Generic;
using service; // This is your interface namespace


public class CustomerServiceProviderImpl : ICustomerServiceProvider
{
    //  stores all created accounts
    protected List<Account> accountList = new List<Account>();

    // 1. Check account balance
    public float GetAccountBalance(long accountNumber)
    {
        Account acc = FindAccount(accountNumber);
        if (acc != null)
        {
            Console.WriteLine($"Balance for account {accountNumber} is: {acc.AccountBalance}");
            return acc.AccountBalance;
        }
        return 0;
    }

    // 2. Deposit money
    public float Deposit(long accountNumber, float amount)
    {
        Account acc = FindAccount(accountNumber);
        if (acc != null)
        {
            acc.AccountBalance += amount;
            Console.WriteLine($"Deposited {amount}. New balance: {acc.AccountBalance}");
            return acc.AccountBalance;
        }
        return 0;
    }

    // 3. Withdraw money (based on rules in each account type)
    public float Withdraw(long accountNumber, float amount)
    {
        Account acc = FindAccount(accountNumber);
        if (acc != null)
        {
            float oldBalance = acc.AccountBalance;
            acc.Withdraw(amount); // Calls the right Withdraw() method
            if (oldBalance != acc.AccountBalance)
            {
                Console.WriteLine($"Withdrawn {amount}. New balance: {acc.AccountBalance}");
            }
            return acc.AccountBalance;
        }
        return 0;
    }

    // 4. Transfer money between two accounts
    public void Transfer(long fromAccountNumber, long toAccountNumber, float amount)
    {
        Account fromAcc = FindAccount(fromAccountNumber);
        Account toAcc = FindAccount(toAccountNumber);

        if (fromAcc != null && toAcc != null)
        {
            float oldBalance = fromAcc.AccountBalance;
            fromAcc.Withdraw(amount);
            if (fromAcc.AccountBalance < oldBalance)
            {
                toAcc.AccountBalance += amount;
                Console.WriteLine($"Transferred {amount} from {fromAccountNumber} to {toAccountNumber}");
            }
        }
        else
        {
            Console.WriteLine("One or both account numbers are invalid.");
        }
    }

    // 5. Show account and customer details
    public void GetAccountDetails(long accountNumber)
    {
        Account acc = FindAccount(accountNumber);
        if (acc != null)
        {
            Console.WriteLine("----- Account Details -----");
            Console.WriteLine($"Account Number: {acc.AccountNumber}");
            Console.WriteLine($"Account Type  : {acc.AccountType}");
            Console.WriteLine($"Balance       : {acc.AccountBalance}");
            Console.WriteLine("----- Customer Details -----");
            acc.Customer.DisplayCustomer();
        }
    }

    // Helper method to search account by account number
    private Account FindAccount(long accNo)
    {
        foreach (var acc in accountList)
        {
            if (acc.AccountNumber == accNo)
            {
                return acc;
            }
        }

        Console.WriteLine($"Account {accNo} not found.");
        return null;
    }
}
