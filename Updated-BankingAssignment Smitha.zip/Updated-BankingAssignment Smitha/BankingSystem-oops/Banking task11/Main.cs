﻿using System;

class Program
{
    static void Main(string[] args)
    {
        BankServiceProviderImpl bank = new BankServiceProviderImpl();

        while (true)
        {
            Console.WriteLine("\n===== BANK MENU =====");
            Console.WriteLine("1. Create Account");
            Console.WriteLine("2. Deposit");
            Console.WriteLine("3. Withdraw");
            Console.WriteLine("4. Get Balance");
            Console.WriteLine("5. Get Account Details");
            Console.WriteLine("6. Calculate Interest");
            Console.WriteLine("7. List All Accounts");
            Console.WriteLine("8. Transfer");
            Console.WriteLine("9. Exit");

            Console.Write("Enter your choice: ");
            int choice = int.Parse(Console.ReadLine());

            if (choice == 1)
            {
                Customer customer = new Customer();
                Console.Write("Customer ID: ");
                customer.CustomerId = int.Parse(Console.ReadLine());
                Console.Write("First Name: ");
                customer.FirstName = Console.ReadLine();
                Console.Write("Last Name: ");
                customer.LastName = Console.ReadLine();
                Console.Write("Email: ");
                customer.EmailAddress = Console.ReadLine();
                Console.Write("Phone: ");
                customer.PhoneNumber = Console.ReadLine();
                Console.Write("Address: ");
                customer.Address = Console.ReadLine();

                Console.Write("Account Type (Savings/Current/ZeroBalance): ");
                string accType = Console.ReadLine();

                float balance = 0;
                if (accType.ToLower() != "zerobalance")
                {
                    Console.Write("Initial Balance: ");
                    balance = float.Parse(Console.ReadLine());
                }

                bank.CreateAccount(customer, accType, balance);
            }
            else if (choice == 2)
            {
                Console.Write("Account No: ");
                long accNo = long.Parse(Console.ReadLine());
                Console.Write("Deposit Amount: ");
                float amount = float.Parse(Console.ReadLine());
                bank.Deposit(accNo, amount);
            }
            else if (choice == 3)
            {
                Console.Write("Account No: ");
                long accNo = long.Parse(Console.ReadLine());
                Console.Write("Withdraw Amount: ");
                float amount = float.Parse(Console.ReadLine());
                bank.Withdraw(accNo, amount);
            }
            else if (choice == 4)
            {
                Console.Write("Account No: ");
                long accNo = long.Parse(Console.ReadLine());
                bank.GetAccountBalance(accNo);
            }
            else if (choice == 5)
            {
                Console.Write("Account No: ");
                long accNo = long.Parse(Console.ReadLine());
                bank.GetAccountDetails(accNo);
            }
            else if (choice == 6)
            {
                bank.CalculateInterest();
            }
            else if (choice == 7)
            {
                bank.ListAccounts();
            }
            else if (choice == 8)
            {
                Console.Write("From Account No: ");
                long fromAcc = long.Parse(Console.ReadLine());
                Console.Write("To Account No: ");
                long toAcc = long.Parse(Console.ReadLine());
                Console.Write("Transfer Amount: ");
                float amount = float.Parse(Console.ReadLine());
                bank.Transfer(fromAcc, toAcc, amount);
            }
            else if (choice == 9)
            {
                Console.WriteLine("Thank you for using the Bank App. Goodbye!");
                break;
            }
            else
            {
                Console.WriteLine("Invalid choice. Try again.");
            }
        }
    }
}
