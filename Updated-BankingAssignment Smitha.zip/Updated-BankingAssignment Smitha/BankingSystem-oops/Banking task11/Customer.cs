﻿using System;

public class Customer
{
    public int CustomerId;
    public string FirstName;
    public string LastName;
    public string EmailAddress;
    public string PhoneNumber;
    public string Address;

    public void DisplayCustomer()
    {
        Console.WriteLine($"Customer ID: {CustomerId}");
        Console.WriteLine($"Name: {FirstName} {LastName}");
        Console.WriteLine($"Email: {EmailAddress}");
        Console.WriteLine($"Phone: {PhoneNumber}");
        Console.WriteLine($"Address: {Address}");
    }
}
