﻿using System;
using service;
using System.Collections.Generic;

public class BankServiceProviderImpl : CustomerServiceProviderImpl, IBankServiceProvider
{
    public string BranchName { get; set; } = "Hexaware Bank";
    public string BranchAddress { get; set; } = "Main Street, Mangalore";

    
    public void CreateAccount(Customer customer, string accType, float balance)
    {
        Account account = null;

        if (accType.ToLower() == "savings")
        {
            if (balance < 500)
            {
                Console.WriteLine("Savings Account requires minimum balance of 500.");
                return;
            }
            account = new SavingsAccount(balance, customer);
        }
        else if (accType.ToLower() == "current")
        {
            account = new CurrentAccount(balance, customer);
        }
        else if (accType.ToLower() == "zerobalance")
        {
            if (balance != 0)
            {
                Console.WriteLine("ZeroBalance Account must start with 0.");
                return;
            }
            account = new ZeroBalanceAccount(customer);
        }
        else
        {
            Console.WriteLine("Invalid account type.");
            return;
        }

        // Add to account list
        accountList.Add(account);
        Console.WriteLine($"Account created successfully. Account Number: {account.AccountNumber}");
    }

    
    public void ListAccounts()
    {
        Console.WriteLine("----- All Accounts -----");
        foreach (var acc in accountList)
        {
            Console.WriteLine($"Account No: {acc.AccountNumber}, Type: {acc.AccountType}, Balance: {acc.AccountBalance}");
        }
    }

    // Calculate interest for all SavingsAccounts
    public void CalculateInterest()
    {
        foreach (var acc in accountList)
        {
            if (acc is SavingsAccount s)
            {
                s.CalculateInterest();
                Console.WriteLine($"Interest added to Account {s.AccountNumber}. New Balance: {s.AccountBalance}");
            }
        }
    }
}
