﻿using System;

public class CurrentAccount : Account
{
    public float OverdraftLimit = 10000;

    public CurrentAccount(float balance, Customer customer)
        : base("Current", balance, customer) { }

    public override void Withdraw(float amount)
    {
        if (AccountBalance - amount >= -OverdraftLimit)
            AccountBalance -= amount;
        else
            Console.WriteLine("Cannot withdraw! Overdraft limit exceeded.");
    }
}
