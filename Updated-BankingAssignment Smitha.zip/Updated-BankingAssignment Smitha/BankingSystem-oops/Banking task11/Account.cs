﻿public abstract class Account
{
    private static long lastAccNo = 1000;
    public long AccountNumber;
    public string AccountType;
    public float AccountBalance;
    public Customer Customer;

    public Account(string accType, float balance, Customer customer)
    {
        AccountNumber = ++lastAccNo;
        AccountType = accType;
        AccountBalance = balance;
        Customer = customer;
    }

    public abstract void Withdraw(float amount);
}
