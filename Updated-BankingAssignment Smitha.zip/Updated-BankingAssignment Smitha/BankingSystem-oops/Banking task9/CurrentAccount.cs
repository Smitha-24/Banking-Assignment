﻿using System;

public class CurrentAccount : BankAccount
{
    private const double overdraftLimit = 5000;

    public CurrentAccount(int accountNumber, string customerName, double balance)
        : base(accountNumber, customerName, balance)
    {
    }

    public override void Deposit(float amount)
    {
        if (amount > 0)
        {
            balance += amount;
            Console.WriteLine("Deposited: " + amount);
        }
        else
        {
            Console.WriteLine("Invalid deposit amount.");
        }
    }

    public override void Withdraw(float amount)
    {
        if (balance + overdraftLimit >= amount)
        {
            balance -= amount;
            Console.WriteLine("Withdrawn: " + amount);
        }
        else
        {
            Console.WriteLine("Withdrawal exceeds overdraft limit.");
        }
    }

    public override void CalculateInterest()
    {
        Console.WriteLine("No interest for current account.");
    }
}
