﻿using System;

class Program
{
    static void Main(string[] args)
    {
        BankAccount account = null;

        Console.WriteLine("Welcome to the Bank");
        Console.WriteLine("1. Create Savings Account");
        Console.WriteLine("2. Create Current Account");
        Console.Write("Enter your choice: ");
        int choice = Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter Account Number: ");
        int accNo = Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter Customer Name: ");
        string custName = Console.ReadLine();

        Console.Write("Enter Initial Balance: ");
        double balance = Convert.ToDouble(Console.ReadLine());

        if (choice == 1)
        {
            Console.Write("Enter Interest Rate: ");
            double rate = Convert.ToDouble(Console.ReadLine());

            account = new SavingsAccount(accNo, custName, balance, rate);
        }
        else if (choice == 2)
        {
            account = new CurrentAccount(accNo, custName, balance);
        }
        else
        {
            Console.WriteLine("Invalid choice.");
            return;
        }

        account.DisplayAccountInfo();

        Console.Write("\nEnter amount to deposit: ");
        float depositAmount = float.Parse(Console.ReadLine());
        account.Deposit(depositAmount);

        Console.Write("\nEnter amount to withdraw: ");
        float withdrawAmount = float.Parse(Console.ReadLine());
        account.Withdraw(withdrawAmount);

        Console.WriteLine("\nCalculating Interest...");
        account.CalculateInterest();

        Console.WriteLine("\nFinal Account Details:");
        account.DisplayAccountInfo();
    }
}
