﻿using System;

public class SavingsAccount : BankAccount
{
    private double interestRate;

    public SavingsAccount(int accountNumber, string customerName, double balance, double interestRate)
        : base(accountNumber, customerName, balance)
    {
        this.interestRate = interestRate;
    }

    public override void Deposit(float amount)
    {
        if (amount > 0)
        {
            balance += amount;
            Console.WriteLine("Deposited: " + amount);
        }
        else
        {
            Console.WriteLine("Invalid deposit amount.");
        }
    }

    public override void Withdraw(float amount)
    {
        if (amount <= balance)
        {
            balance -= amount;
            Console.WriteLine("Withdrawn: " + amount);
        }
        else
        {
            Console.WriteLine("Insufficient balance.");
        }
    }

    public override void CalculateInterest()
    {
        double interest = balance * interestRate / 100;
        balance += interest;
        Console.WriteLine("Interest added: " + interest);
    }
}
