﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Account account = null;

        Console.WriteLine("Welcome to Bank Account Creation");
        Console.WriteLine("1. Savings Account");
        Console.WriteLine("2. Current Account");
        Console.Write("Enter choice (1 or 2): ");
        int choice = Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter Account Number: ");
        int accNo = Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter Initial Balance: ");
        double balance = Convert.ToDouble(Console.ReadLine());

        switch (choice)
        {
            case 1:
                Console.Write("Enter Interest Rate: ");
                double rate = Convert.ToDouble(Console.ReadLine());
                account = new SavingsAccount(accNo, balance, rate);
                break;

            case 2:
                account = new CurrentAccount(accNo, balance);
                break;

            default:
                Console.WriteLine("Invalid choice.");
                return;
        }

        // Display initial details
        account.DisplayAccountInfo();

        // Perform Deposit
        Console.Write("Enter amount to deposit: ");
        double depositAmount = Convert.ToDouble(Console.ReadLine());
        account.Deposit(depositAmount);

        // Perform Withdraw
        Console.Write("Enter amount to withdraw: ");
        double withdrawAmount = Convert.ToDouble(Console.ReadLine());
        account.Withdraw(withdrawAmount);

        // Calculate Interest
        account.CalculateInterest();

        // Display Final Details
        Console.WriteLine("\nFinal Account Details:");
        account.DisplayAccountInfo();
    }
}
