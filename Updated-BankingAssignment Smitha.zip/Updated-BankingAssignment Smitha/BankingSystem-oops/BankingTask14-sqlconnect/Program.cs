﻿

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using bean;
using dao;
using impl;
using service;

namespace dao
{
    public class DBUtil
    {
        public static SqlConnection GetDBConn()
        {
            string connStr = "Server=DESKTOP-6MSAL59;Database=hmbank;Integrated Security=True";
            return new SqlConnection(connStr);
        }
    }
}


namespace bean
{
    public class Customer
    {
        public int CustomerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
    }
}

//----------------------
// Account.cs
// ----------------------
namespace bean
{
    public abstract class Account
    {
        public long AccountNumber { get; set; }
        public string AccountType { get; set; }
        public float Balance { get; set; }
        public Customer Customer { get; set; }
    }

    public class SavingsAccount : Account
    {
        public float InterestRate { get; set; }
    }

    public class CurrentAccount : Account
    {
        public float OverdraftLimit { get; set; }
    }

    public class ZeroBalanceAccount : Account
    {
    }
}

// ----------------------
//  Transaction.cs
// ----------------------
namespace bean
{
    public class Transaction
    {
        public long AccountNumber { get; set; }
        public string Description { get; set; }
        public DateTime DateTime { get; set; }
        public string TransactionType { get; set; }
        public float TransactionAmount { get; set; }
    }
}

// ----------------------
//  ICustomerServiceProvider.cs
// ----------------------
namespace service
{
    public interface ICustomerServiceProvider
    {
        float GetAccountBalance(long accountNumber);
        float Deposit(long accountNumber, float amount);
        float Withdraw(long accountNumber, float amount);
        void Transfer(long fromAccountNumber, long toAccountNumber, float amount);
        Account GetAccountDetails(long accountNumber);
        List<Transaction> GetTransactions(long accountNumber, DateTime from, DateTime to);
    }
}

// ----------------------
//  IBankServiceProvider.cs
// ----------------------
namespace service
{
    public interface IBankServiceProvider
    {
        void CreateAccount(Customer customer, long accNo, string accType, float balance);
        List<Account> ListAccounts();
        Account GetAccountDetails(long accountNumber);
        void CalculateInterest();
    }
}

// ----------------------
//  CustomerServiceProviderImpl.cs
// ----------------------
namespace impl
{
    public class CustomerServiceProviderImpl : ICustomerServiceProvider
    {
        protected List<Account> accountList = new List<Account>();
        protected List<Transaction> transactionList = new List<Transaction>();

        public float GetAccountBalance(long accountNumber)
        {
            using (SqlConnection con = DBUtil.GetDBConn())
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT balance FROM Accounts WHERE account_id=@accId", con);
                cmd.Parameters.AddWithValue("@accId", accountNumber);
                object result = cmd.ExecuteScalar();
                return result != null ? Convert.ToSingle(result) : 0;
            }
        }

        public float Deposit(long accountNumber, float amount)
        {
            float newBalance = 0;
            using (SqlConnection con = DBUtil.GetDBConn())
            {
                con.Open();
                SqlCommand getBal = new SqlCommand("SELECT balance FROM Accounts WHERE account_id=@accId", con);
                getBal.Parameters.AddWithValue("@accId", accountNumber);
                float bal = Convert.ToSingle(getBal.ExecuteScalar());
                newBalance = bal + amount;

                SqlCommand cmd = new SqlCommand("UPDATE Accounts SET balance=@bal WHERE account_id=@accId", con);
                cmd.Parameters.AddWithValue("@bal", newBalance);
                cmd.Parameters.AddWithValue("@accId", accountNumber);
                cmd.ExecuteNonQuery();

                SqlCommand transCmd = new SqlCommand("INSERT INTO Transactions(account_id, description, transaction_type, transaction_amount) VALUES (@accId, 'Deposit', 'Deposit', @amt)", con);
                transCmd.Parameters.AddWithValue("@accId", accountNumber);
                transCmd.Parameters.AddWithValue("@amt", amount);
                transCmd.ExecuteNonQuery();
            }
            return newBalance;
        }

        public float Withdraw(long accountNumber, float amount)
        {
            float newBalance = 0;
            using (SqlConnection con = DBUtil.GetDBConn())
            {
                con.Open();
                SqlCommand getBal = new SqlCommand("SELECT balance FROM Accounts WHERE account_id=@accId", con);
                getBal.Parameters.AddWithValue("@accId", accountNumber);
                float bal = Convert.ToSingle(getBal.ExecuteScalar());

                if (bal - amount < 0)
                    throw new Exception("Insufficient balance.");

                newBalance = bal - amount;
                SqlCommand cmd = new SqlCommand("UPDATE Accounts SET balance=@bal WHERE account_id=@accId", con);
                cmd.Parameters.AddWithValue("@bal", newBalance);
                cmd.Parameters.AddWithValue("@accId", accountNumber);
                cmd.ExecuteNonQuery();

                SqlCommand transCmd = new SqlCommand("INSERT INTO Transactions(account_id, description, transaction_type, transaction_amount) VALUES (@accId, 'Withdraw', 'Withdraw', @amt)", con);
                transCmd.Parameters.AddWithValue("@accId", accountNumber);
                transCmd.Parameters.AddWithValue("@amt", amount);
                transCmd.ExecuteNonQuery();
            }
            return newBalance;
        }

        public void Transfer(long fromAccountNumber, long toAccountNumber, float amount)
        {
            Withdraw(fromAccountNumber, amount);
            Deposit(toAccountNumber, amount);
        }

        public Account GetAccountDetails(long accountNumber)
        {
            return null;
        }

        public List<Transaction> GetTransactions(long accountNumber, DateTime from, DateTime to)
        {
            return new List<Transaction>();
        }
    }
}

// ----------------------
//  BankServiceProviderImpl.cs
// ----------------------
namespace impl
{
    public class BankServiceProviderImpl : CustomerServiceProviderImpl, IBankServiceProvider
    {
        public string BranchName = "Main Branch";
        public string BranchAddress = "Mangalore";

        public void CreateAccount(Customer customer, long accNo, string accType, float balance)
        {
            Account account;
            if (accType == "Savings")
                account = new SavingsAccount { InterestRate = 4.0f };
            else if (accType == "Current")
                account = new CurrentAccount { OverdraftLimit = 2000.0f };
            else
                account = new ZeroBalanceAccount();

            account.AccountType = accType;
            account.Balance = balance;
            account.Customer = customer;

            using (SqlConnection con = DBUtil.GetDBConn())
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Customers(first_name, last_name, email, phone, address) OUTPUT INSERTED.customer_id VALUES (@fn, @ln, @em, @ph, @ad)", con);
                cmd.Parameters.AddWithValue("@fn", customer.FirstName);
                cmd.Parameters.AddWithValue("@ln", customer.LastName);
                cmd.Parameters.AddWithValue("@em", customer.Email);
                cmd.Parameters.AddWithValue("@ph", customer.Phone);
                cmd.Parameters.AddWithValue("@ad", customer.Address);
                int customerId = (int)cmd.ExecuteScalar();

                SqlCommand accCmd = new SqlCommand("INSERT INTO Accounts(customer_id, account_type, balance) OUTPUT INSERTED.account_id VALUES (@cid, @type, @bal)", con);
                accCmd.Parameters.AddWithValue("@cid", customerId);
                accCmd.Parameters.AddWithValue("@type", accType);
                accCmd.Parameters.AddWithValue("@bal", balance);
                long generatedAccountId = (long)accCmd.ExecuteScalar();

                account.AccountNumber = generatedAccountId;
                Console.WriteLine("Account created successfully. Account Number: " + generatedAccountId);
            }
        }

        public List<Account> ListAccounts()
        {
            return accountList;
        }

        public void CalculateInterest()
        {
            foreach (var acc in accountList)
            {
                if (acc is SavingsAccount sa)
                {
                    acc.Balance += acc.Balance * (sa.InterestRate / 100);
                }
            }
        }
    }
}

// ----------------------
//  BankApp.cs
// ----------------------
namespace app
{
    class BankApp
    {
        static void Main()
        {
            BankServiceProviderImpl bank = new BankServiceProviderImpl();
            bool run = true;

            while (run)
            {
                Console.WriteLine("\nMenu: 1.Create Account 2.Deposit 3.Withdraw 4.Balance 5.Transfer 6.Exit");
                Console.Write("Enter your choice: ");
                int ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        Console.Write("Enter First Name: ");
                        string fname = Console.ReadLine();
                        Console.Write("Enter Last Name: ");
                        string lname = Console.ReadLine();
                        Console.Write("Enter Email: ");
                        string email = Console.ReadLine();
                        Console.Write("Enter Phone: ");
                        string phone = Console.ReadLine();
                        Console.Write("Enter Address: ");
                        string addr = Console.ReadLine();
                        Console.Write("Enter Account Type (Savings/Current/ZeroBalance): ");
                        string type = Console.ReadLine();
                        Console.Write("Enter Balance: ");
                        float bal = float.Parse(Console.ReadLine());
                        bank.CreateAccount(new Customer { FirstName = fname, LastName = lname, Email = email, Phone = phone, Address = addr }, 0, type, bal);
                        break;
                    case 2:
                        Console.Write("Enter AccNo: ");
                        long dacc = long.Parse(Console.ReadLine());
                        Console.Write("Enter Amount: ");
                        float damt = float.Parse(Console.ReadLine());
                        Console.WriteLine("New Balance: " + bank.Deposit(dacc, damt));
                        break;
                    case 3:
                        Console.Write("Enter AccNo: ");
                        long wacc = long.Parse(Console.ReadLine());
                        Console.Write("Enter Amount: ");
                        float wamt = float.Parse(Console.ReadLine());
                        Console.WriteLine("New Balance: " + bank.Withdraw(wacc, wamt));
                        break;
                    case 4:
                        Console.Write("Enter AccNo: ");
                        long bacc = long.Parse(Console.ReadLine());
                        Console.WriteLine("Balance: " + bank.GetAccountBalance(bacc));
                        break;
                    case 5:
                        Console.Write("From AccNo: ");
                        long facc = long.Parse(Console.ReadLine());
                        Console.Write("To AccNo: ");
                        long tacc = long.Parse(Console.ReadLine());
                        Console.Write("Amount: ");
                        float tamt = float.Parse(Console.ReadLine());
                        bank.Transfer(facc, tacc, tamt);
                        Console.WriteLine("Transferred.");
                        break;
                    case 6:
                        run = false;
                        break;
                }
            }
        }
    }
}




