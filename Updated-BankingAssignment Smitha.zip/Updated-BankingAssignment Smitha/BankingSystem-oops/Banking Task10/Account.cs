﻿using System;

public class Account
{
    public long AccountNumber { get; set; }
    public string AccountType { get; set; }
    public float AccountBalance { get; set; }
    public Customer Customer { get; set; }

    public Account() { }

    public Account(long accNo, string accType, float balance, Customer customer)
    {
        AccountNumber = accNo;
        AccountType = accType;
        AccountBalance = balance;
        Customer = customer;
    }

    public void DisplayAccount()
    {
        Console.WriteLine($"\nAccount Number: {AccountNumber}");
        Console.WriteLine($"Account Type: {AccountType}");
        Console.WriteLine($"Balance: {AccountBalance}");
        Customer.DisplayCustomer();
    }
}
