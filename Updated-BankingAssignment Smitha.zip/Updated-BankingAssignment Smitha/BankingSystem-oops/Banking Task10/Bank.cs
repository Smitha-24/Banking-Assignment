﻿using System;

public class Bank
{
    private Account[] accounts = new Account[100];
    private int totalAccounts = 0;
    private long accountNumberCounter = 1001;

    public Account CreateAccount(Customer customer, string accType, float balance)
    {
        long newAccNo = accountNumberCounter++;
        Account acc = new Account(newAccNo, accType, balance, customer);
        accounts[totalAccounts] = acc;
        totalAccounts++;
        Console.WriteLine($"\nAccount created! Account Number: {newAccNo}");
        return acc;
    }

    public Account FindAccount(long accNo)
    {
        for (int i = 0; i < totalAccounts; i++)
        {
            if (accounts[i].AccountNumber == accNo)
                return accounts[i];
        }
        Console.WriteLine("Account not found.");
        return null;
    }

    public float Deposit(long accNo, float amount)
    {
        Account acc = FindAccount(accNo);
        if (acc != null)
        {
            acc.AccountBalance += amount;
            return acc.AccountBalance;
        }
        return 0;
    }

    public float Withdraw(long accNo, float amount)
    {
        Account acc = FindAccount(accNo);
        if (acc != null)
        {
            if (acc.AccountBalance >= amount)
            {
                acc.AccountBalance -= amount;
                return acc.AccountBalance;
            }
            else
            {
                Console.WriteLine("Insufficient Balance");
            }
        }
        return 0;
    }

    public void Transfer(long fromAcc, long toAcc, float amount)
    {
        float beforeWithdraw = Withdraw(fromAcc, amount);
        if (beforeWithdraw != 0)
        {
            Deposit(toAcc, amount);
            Console.WriteLine("Transfer Successful");
        }
    }

    public float GetBalance(long accNo)
    {
        Account acc = FindAccount(accNo);
        if (acc != null)
            return acc.AccountBalance;
        return 0;
    }

    public void GetAccountDetails(long accNo)
    {
        Account acc = FindAccount(accNo);
        if (acc != null)
            acc.DisplayAccount();
    }
}
