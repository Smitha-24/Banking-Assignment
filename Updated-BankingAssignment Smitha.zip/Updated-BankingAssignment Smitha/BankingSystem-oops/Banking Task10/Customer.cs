﻿using System;

public class Customer
{
    public int CustomerId { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string EmailAddress { get; set; }
    public string PhoneNumber { get; set; }
    public string Address { get; set; }

    public Customer() { }

    public Customer(int id, string firstName, string lastName, string email, string phone, string address)
    {
        CustomerId = id;
        FirstName = firstName;
        LastName = lastName;
        EmailAddress = email;
        PhoneNumber = phone;
        Address = address;
    }

    public void DisplayCustomer()
    {
        Console.WriteLine($"Customer ID: {CustomerId}");
        Console.WriteLine($"Name: {FirstName} {LastName}");
        Console.WriteLine($"Email: {EmailAddress}");
        Console.WriteLine($"Phone: {PhoneNumber}");
        Console.WriteLine($"Address: {Address}");
    }
}
