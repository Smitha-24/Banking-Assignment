﻿//using System;
//using System.Collections.Generic;
//using System.Data.SqlClient;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using CareerHub.util;

//namespace CareerHub
//{
//    internal class TestConnection
//    {
//        static void Main(string[] args)
//        {
//            try
//            {
//                SqlConnection conn = DBConnUtil.GetConnection();
//                conn.Open();
//                Console.WriteLine(" Connection Successful!");
//                conn.Close();
//            }
//            catch (Exception ex)
//            {
//                Console.WriteLine(" Connection Failed: " + ex.Message);
//            }

//        }
//    }
//}
