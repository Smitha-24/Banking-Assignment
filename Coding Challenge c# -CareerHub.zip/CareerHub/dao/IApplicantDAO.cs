﻿using CareerHub.entity;
using System.Collections.Generic;

namespace CareerHub.dao
{
    public interface IApplicantDAO
    {
        void InsertApplicant(Applicant applicant);
        List<Applicant> GetAllApplicants();
    }
}
