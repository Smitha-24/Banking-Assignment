﻿using CareerHub.entity;
using CareerHub.util;
using CareerHub.exception;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;

namespace CareerHub.dao
{
    public class ApplicantDAOImpl : IApplicantDAO
    {
        public void InsertApplicant(Applicant applicant)
        {
            try
            {
                if (!applicant.Email.Contains("@") || !applicant.Email.Contains("."))
                    throw new InvalidEmailException("Invalid email format.");

                if (!File.Exists(applicant.Resume))
                    throw new FileUploadException("Resume file not found.");

                FileInfo fileInfo = new FileInfo(applicant.Resume);
                if (fileInfo.Length > 2 * 1024 * 1024)
                    throw new FileUploadException("File size exceeds 2MB.");

                string ext = Path.GetExtension(applicant.Resume).ToLower();
                if (ext != ".pdf" && ext != ".docx" && ext != ".txt")
                    throw new FileUploadException("Unsupported file format.");

                using (SqlConnection conn = DBConnUtil.GetConnection())
                {
                    conn.Open();
                    string query = @"INSERT INTO Applicants (FirstName, LastName, Email, Phone, Resume) 
                                     VALUES (@fn, @ln, @em, @ph, @res)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@fn", applicant.FirstName);
                    cmd.Parameters.AddWithValue("@ln", applicant.LastName);
                    cmd.Parameters.AddWithValue("@em", applicant.Email);
                    cmd.Parameters.AddWithValue("@ph", applicant.Phone);
                    cmd.Parameters.AddWithValue("@res", applicant.Resume);
                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Applicant inserted successfully.");
                }
            }
            catch (InvalidEmailException ex)
            {
                Console.WriteLine("Email Error: " + ex.Message);
            }
            catch (FileUploadException ex)
            {
                Console.WriteLine("Resume Error: " + ex.Message);
            }
            catch (SqlException sqlEx)
            {
                Console.WriteLine("Database error: " + sqlEx.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected error: " + ex.Message);
            }
        }

        public List<Applicant> GetAllApplicants()
        {
            List<Applicant> applicants = new List<Applicant>();

            try
            {
                using (SqlConnection conn = DBConnUtil.GetConnection())
                {
                    conn.Open();
                    string query = "SELECT * FROM Applicants";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Applicant a = new Applicant
                        {
                            ApplicantID = (int)reader["ApplicantID"],
                            FirstName = reader["FirstName"].ToString(),
                            LastName = reader["LastName"].ToString(),
                            Email = reader["Email"].ToString(),
                            Phone = reader["Phone"].ToString(),
                            Resume = reader["Resume"].ToString()
                        };
                        applicants.Add(a);
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                Console.WriteLine("Database error: " + sqlEx.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected error: " + ex.Message);
            }

            return applicants;
        }
    }
}
