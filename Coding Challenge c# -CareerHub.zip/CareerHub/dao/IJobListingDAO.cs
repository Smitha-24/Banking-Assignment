﻿using CareerHub.entity;
using System.Collections.Generic;

namespace CareerHub.dao
{
    public interface IJobListingDAO
    {
        void InsertJob(JobListing job);
        List<JobListing> GetAllJobs();

        //  METHOD FOR SALARY RANGE SEARCH
        List<JobListing> GetJobsBySalaryRange(decimal minSalary, decimal maxSalary);
    }
}
