﻿using CareerHub.entity;
using CareerHub.util;
using CareerHub.exception;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace CareerHub.dao
{
    public class JobApplicationDAOImpl : IJobApplicationDAO
    {
        public void InsertApplication(JobApplication app)
        {
            try
            {
                using (SqlConnection conn = DBConnUtil.GetConnection())
                {
                    conn.Open();

                    // Deadline check
                    string jobQuery = "SELECT PostedDate FROM Jobs WHERE JobID = @jobID";
                    SqlCommand checkJob = new SqlCommand(jobQuery, conn);
                    checkJob.Parameters.AddWithValue("@jobID", app.JobID);
                    object result = checkJob.ExecuteScalar();

                    if (result == null)
                        throw new Exception("Job not found.");

                    DateTime postedDate = Convert.ToDateTime(result);
                    DateTime deadline = postedDate.AddDays(3);

                    if (app.ApplicationDate > deadline)
                        throw new ApplicationDeadlineException("Application deadline has passed.");

                    // Insert application
                    string query = @"INSERT INTO Applications (JobID, ApplicantID, ApplicationDate, CoverLetter)
                                     VALUES (@jobID, @appID, @date, @cover)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@jobID", app.JobID);
                    cmd.Parameters.AddWithValue("@appID", app.ApplicantID);
                    cmd.Parameters.AddWithValue("@date", app.ApplicationDate);
                    cmd.Parameters.AddWithValue("@cover", app.CoverLetter);
                    cmd.ExecuteNonQuery();

                    Console.WriteLine("Application submitted successfully.");
                }
            }
            catch (ApplicationDeadlineException ex)
            {
                Console.WriteLine("Deadline Error: " + ex.Message);
            }
            catch (SqlException sqlEx)
            {
                Console.WriteLine("Database error: " + sqlEx.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected error: " + ex.Message);
            }
        }

        public List<JobApplication> GetApplicationsByJobID(int jobID)
        {
            List<JobApplication> apps = new List<JobApplication>();

            try
            {
                using (SqlConnection conn = DBConnUtil.GetConnection())
                {
                    conn.Open();
                    string query = "SELECT * FROM Applications WHERE JobID = @jobID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@jobID", jobID);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        JobApplication app = new JobApplication
                        {
                            ApplicationID = (int)reader["ApplicationID"],
                            JobID = (int)reader["JobID"],
                            ApplicantID = (int)reader["ApplicantID"],
                            ApplicationDate = Convert.ToDateTime(reader["ApplicationDate"]),
                            CoverLetter = reader["CoverLetter"].ToString()
                        };
                        apps.Add(app);
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                Console.WriteLine("Database error: " + sqlEx.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected error: " + ex.Message);
            }

            return apps;
        }
    }
}
