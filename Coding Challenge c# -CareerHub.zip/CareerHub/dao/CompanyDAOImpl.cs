﻿using CareerHub.entity;
using CareerHub.util;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace CareerHub.dao
{
    public class CompanyDAOImpl : ICompanyDAO
    {
        public void InsertCompany(Company company)
        {
            try
            {
                using (SqlConnection conn = DBConnUtil.GetConnection())
                {
                    conn.Open();
                    string query = "INSERT INTO Companies (CompanyName, Location) VALUES (@name, @loc)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@name", company.CompanyName);
                    cmd.Parameters.AddWithValue("@loc", company.Location);
                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Company inserted successfully.");
                }
            }
            catch (SqlException sqlEx)
            {
                Console.WriteLine("Database error: " + sqlEx.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected error: " + ex.Message);
            }
        }

        public List<Company> GetAllCompanies()
        {
            List<Company> companies = new List<Company>();

            try
            {
                using (SqlConnection conn = DBConnUtil.GetConnection())
                {
                    conn.Open();
                    string query = "SELECT * FROM Companies";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Company c = new Company
                        {
                            CompanyID = (int)reader["CompanyID"],
                            CompanyName = reader["CompanyName"].ToString(),
                            Location = reader["Location"].ToString()
                        };
                        companies.Add(c);
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                Console.WriteLine("Database error: " + sqlEx.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected error: " + ex.Message);
            }

            return companies;
        }
    }
}
