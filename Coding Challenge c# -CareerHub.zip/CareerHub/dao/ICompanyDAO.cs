﻿using CareerHub.entity;
using System.Collections.Generic;

namespace CareerHub.dao
{
    public interface ICompanyDAO
    {
        void InsertCompany(Company company);
        List<Company> GetAllCompanies();
    }
}
