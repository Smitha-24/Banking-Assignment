﻿using CareerHub.entity;
using CareerHub.util;
using CareerHub.exception;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace CareerHub.dao
{
    public class JobListingDAOImpl : IJobListingDAO
    {
        public void InsertJob(JobListing job)
        {
            try
            {
                if (job.Salary < 0)
                    throw new NegativeSalaryException("Salary cannot be negative.");

                using (SqlConnection conn = DBConnUtil.GetConnection())
                {
                    conn.Open();
                    string query = @"INSERT INTO Jobs (CompanyID, JobTitle, JobDescription, JobLocation, Salary, JobType, PostedDate)
                                     VALUES (@cid, @title, @desc, @loc, @sal, @type, @date)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@cid", job.CompanyID);
                    cmd.Parameters.AddWithValue("@title", job.JobTitle);
                    cmd.Parameters.AddWithValue("@desc", job.JobDescription);
                    cmd.Parameters.AddWithValue("@loc", job.JobLocation);
                    cmd.Parameters.AddWithValue("@sal", job.Salary);
                    cmd.Parameters.AddWithValue("@type", job.JobType);
                    cmd.Parameters.AddWithValue("@date", job.PostedDate);
                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Job posted successfully.");
                }
            }
            catch (NegativeSalaryException ex)
            {
                Console.WriteLine("Salary Error: " + ex.Message);
            }
            catch (SqlException sqlEx)
            {
                Console.WriteLine("Database error: " + sqlEx.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected error: " + ex.Message);
            }
        }

        public List<JobListing> GetAllJobs()
        {
            List<JobListing> jobs = new List<JobListing>();

            try
            {
                using (SqlConnection conn = DBConnUtil.GetConnection())
                {
                    conn.Open();
                    string query = "SELECT * FROM Jobs";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        JobListing job = new JobListing
                        {
                            JobID = (int)reader["JobID"],
                            CompanyID = (int)reader["CompanyID"],
                            JobTitle = reader["JobTitle"].ToString(),
                            JobDescription = reader["JobDescription"].ToString(),
                            JobLocation = reader["JobLocation"].ToString(),
                            Salary = Convert.ToDecimal(reader["Salary"]),
                            JobType = reader["JobType"].ToString(),
                            PostedDate = Convert.ToDateTime(reader["PostedDate"])
                        };
                        jobs.Add(job);
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                Console.WriteLine("Database error: " + sqlEx.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected error: " + ex.Message);
            }

            return jobs;
        }

        public List<JobListing> GetJobsBySalaryRange(decimal minSalary, decimal maxSalary)
        {
            List<JobListing> jobs = new List<JobListing>();

            try
            {
                using (SqlConnection conn = DBConnUtil.GetConnection())
                {
                    conn.Open();
                    string query = @"SELECT * FROM Jobs WHERE Salary BETWEEN @min AND @max";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@min", minSalary);
                    cmd.Parameters.AddWithValue("@max", maxSalary);

                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        JobListing job = new JobListing
                        {
                            JobID = (int)reader["JobID"],
                            CompanyID = (int)reader["CompanyID"],
                            JobTitle = reader["JobTitle"].ToString(),
                            JobDescription = reader["JobDescription"].ToString(),
                            JobLocation = reader["JobLocation"].ToString(),
                            Salary = Convert.ToDecimal(reader["Salary"]),
                            JobType = reader["JobType"].ToString(),
                            PostedDate = Convert.ToDateTime(reader["PostedDate"])
                        };
                        jobs.Add(job);
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                Console.WriteLine("Database error: " + sqlEx.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected error: " + ex.Message);
            }

            return jobs;
        }
    }
}
