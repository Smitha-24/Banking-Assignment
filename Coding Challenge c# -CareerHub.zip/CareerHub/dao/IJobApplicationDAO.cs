﻿using CareerHub.entity;
using System.Collections.Generic;

namespace CareerHub.dao
{
    public interface IJobApplicationDAO
    {
        void InsertApplication(JobApplication app);
        List<JobApplication> GetApplicationsByJobID(int jobID);
    }
}
