﻿using System;

namespace CareerHub.exception
{
    public class FileTooLargeException : Exception
    {
        public FileTooLargeException(string message) : base(message) { }
    }
}
