﻿using System;

namespace CareerHub.exception
{
    public class InvalidFileFormatException : Exception
    {
        public InvalidFileFormatException(string message) : base(message) { }
    }
}
