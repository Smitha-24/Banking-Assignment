﻿using System;

namespace CareerHub.exception
{
    public class ApplicationDeadlineException : Exception
    {
        public ApplicationDeadlineException(string message) : base(message)
        {
        }
    }
}
