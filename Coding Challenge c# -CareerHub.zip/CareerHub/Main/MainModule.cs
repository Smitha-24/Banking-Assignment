﻿using CareerHub.dao;
using CareerHub.entity;
using System;
using System.Collections.Generic;

namespace CareerHub.Main
{
    class MainModule
    {
        static void Main(string[] args)
        {
            ICompanyDAO companyDAO = new CompanyDAOImpl();
            IApplicantDAO applicantDAO = new ApplicantDAOImpl();
            IJobListingDAO jobDAO = new JobListingDAOImpl();
            IJobApplicationDAO applicationDAO = new JobApplicationDAOImpl();

            while (true)
            {
                Console.WriteLine("\n=== CareerHub Job Board ===");
                Console.WriteLine("1. Register Company");
                Console.WriteLine("2. View Companies");
                Console.WriteLine("3. Register Applicant");
                Console.WriteLine("4. View Applicants");
                Console.WriteLine("5. Post a Job");
                Console.WriteLine("6. View All Jobs");
                Console.WriteLine("7. Apply for a Job");
                Console.WriteLine("8. View Applications for a Job");
                Console.WriteLine("9. Search Jobs by Salary Range");
                Console.WriteLine("0. Exit");
                Console.Write("Enter your choice: ");

                int choice;
                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Invalid input. Enter a valid number.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        Company c = new Company();
                        Console.Write("Enter Company Name: ");
                        c.CompanyName = Console.ReadLine();
                        Console.Write("Enter Location: ");
                        c.Location = Console.ReadLine();
                        companyDAO.InsertCompany(c);
                        break;

                    case 2:
                        List<Company> companies = companyDAO.GetAllCompanies();
                        Console.WriteLine("\n--- Companies ---");
                        foreach (var comp in companies)
                        {
                            Console.WriteLine($"{comp.CompanyID} - {comp.CompanyName} - {comp.Location}");
                        }
                        break;

                    case 3:
                        Applicant a = new Applicant();
                        Console.Write("Enter First Name: ");
                        a.FirstName = Console.ReadLine();
                        Console.Write("Enter Last Name: ");
                        a.LastName = Console.ReadLine();
                        Console.Write("Enter Email: ");
                        a.Email = Console.ReadLine();
                        Console.Write("Enter Phone: ");
                        a.Phone = Console.ReadLine();
                        Console.Write("Enter Resume Path (e.g., ResumePath\\your_resume.txt): ");
                        a.Resume = Console.ReadLine();
                        applicantDAO.InsertApplicant(a);
                        break;

                    case 4:
                        List<Applicant> applicants = applicantDAO.GetAllApplicants();
                        Console.WriteLine("\n--- Applicants ---");
                        foreach (var app in applicants)
                        {
                            Console.WriteLine($"{app.ApplicantID} - {app.FirstName} {app.LastName} - {app.Email} - {app.Phone}");
                        }
                        break;

                    case 5:
                        JobListing job = new JobListing();
                        Console.Write("Enter Company ID: ");
                        job.CompanyID = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter Job Title: ");
                        job.JobTitle = Console.ReadLine();
                        Console.Write("Enter Job Description: ");
                        job.JobDescription = Console.ReadLine();
                        Console.Write("Enter Job Location: ");
                        job.JobLocation = Console.ReadLine();
                        Console.Write("Enter Salary: ");
                        job.Salary = Convert.ToDecimal(Console.ReadLine());
                        Console.Write("Enter Job Type (Full-time/Part-time/Contract): ");
                        job.JobType = Console.ReadLine();
                        job.PostedDate = DateTime.Now;
                        jobDAO.InsertJob(job);
                        break;

                    case 6:
                        List<JobListing> jobs = jobDAO.GetAllJobs();
                        Console.WriteLine("\n--- All Job Listings ---");
                        foreach (var j in jobs)
                        {
                            Console.WriteLine($"{j.JobID} - {j.JobTitle} - {j.JobLocation} - ₹{j.Salary} - {j.JobType}");
                        }
                        break;

                    case 7:
                        JobApplication application = new JobApplication();
                        Console.Write("Enter Job ID: ");
                        application.JobID = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter Your Applicant ID: ");
                        application.ApplicantID = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter Cover Letter: ");
                        application.CoverLetter = Console.ReadLine();
                        application.ApplicationDate = DateTime.Now;
                        applicationDAO.InsertApplication(application);
                        break;

                    case 8:
                        Console.Write("Enter Job ID to view applications: ");
                        int jobID = Convert.ToInt32(Console.ReadLine());
                        List<JobApplication> apps = applicationDAO.GetApplicationsByJobID(jobID);
                        Console.WriteLine($"\n--- Applications for Job ID {jobID} ---");
                        foreach (var app in apps)
                        {
                            Console.WriteLine($"ApplicationID: {app.ApplicationID}, ApplicantID: {app.ApplicantID}, Date: {app.ApplicationDate}, Cover: {app.CoverLetter}");
                        }
                        break;

                    case 9:
                        Console.Write("Enter minimum salary: ");
                        decimal minSalary = Convert.ToDecimal(Console.ReadLine());
                        Console.Write("Enter maximum salary: ");
                        decimal maxSalary = Convert.ToDecimal(Console.ReadLine());
                        List<JobListing> jobsInRange = jobDAO.GetJobsBySalaryRange(minSalary, maxSalary);
                        Console.WriteLine("\n--- Jobs in Salary Range ---");
                        foreach (var jobItem in jobsInRange)
                        {
                            Console.WriteLine($"{jobItem.JobID} - {jobItem.JobTitle} - {jobItem.JobLocation} - ₹{jobItem.Salary}");
                        }
                        break;

                    case 0:
                        Console.WriteLine("Exiting CareerHub. Goodbye.");
                        return;

                    default:
                        Console.WriteLine("Invalid choice. Try again.");
                        break;
                }
            }
        }
    }
}
