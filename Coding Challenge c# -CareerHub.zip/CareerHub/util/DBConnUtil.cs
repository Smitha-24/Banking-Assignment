﻿using System.Data.SqlClient;

namespace CareerHub.util
{
    public class DBConnUtil
    {
        public static SqlConnection GetConnection()
        {
            
            string serverName = "DESKTOP-6MSAL59";
            string databaseName = "CareerHubDB";

            string connectionString = $"Data Source={serverName};Initial Catalog={databaseName};Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionString);
            return conn;
        }
    }
}
