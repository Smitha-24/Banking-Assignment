﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace BankingSystem
//{
//    internal class task4
//    {
//        static void Main()
//        {

//            int[] accountNumbers = { 101, 102, 103, 104, 105 };
//            double[] balances = { 5000, 10000, 7500, 2000, 15000 };

//            bool validAccount = false;

//            while (!validAccount)
//            {
//                Console.Write("Enter your account number: ");
//                int enteredAccount = int.Parse(Console.ReadLine());

//                // Search for account number
//                for (int i = 0; i < accountNumbers.Length; i++)
//                {
//                    if (enteredAccount == accountNumbers[i])
//                    {
//                        Console.WriteLine("Account Found!");
//                        Console.WriteLine("Your balance is: $" + balances[i]);
//                        validAccount = true;  // exit loop
//                        break;
//                    }
//                }

//                if (!validAccount)
//                {
//                    Console.WriteLine("Invalid account number. Please try again.");
//                }
//            }
//        }
//    }
//}
