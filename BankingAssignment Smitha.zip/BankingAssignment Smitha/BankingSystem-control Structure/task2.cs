﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace BankingSystem
//{
//    internal class task2
//    {
//        static void Main(string[] args)
//        {
//            Console.Write("Enter current balance: ");
//            double balance = double.Parse(Console.ReadLine());

//            Console.WriteLine("1. Check Balance");
//            Console.WriteLine("2. Withdraw");
//            Console.WriteLine("3. Deposit");
//            Console.Write("Enter your choice: ");
//            int choice = int.Parse(Console.ReadLine());

//            if (choice == 1)
//            {
//                Console.WriteLine("Balance: $" + balance);
//            }
//            else if (choice == 2)
//            {
//                Console.Write("Enter amount to withdraw: ");
//                double withdraw = double.Parse(Console.ReadLine());

//                if (withdraw > balance)
//                {
//                    Console.WriteLine("Not enough balance");
//                }
//                else if (withdraw % 100 != 0 && withdraw % 500 != 0)
//                {
//                    Console.WriteLine("Withdrawal must be multiple of 100 or 500");
//                }
//                else
//                {
//                    balance -= withdraw;
//                    Console.WriteLine("Withdrawn. New balance: $" + balance);
//                }
//            }
//            else if (choice == 3)
//            {
//                Console.Write("Enter amount to deposit: ");
//                double deposit = double.Parse(Console.ReadLine());
//                balance += deposit;
//                Console.WriteLine("Deposited. New balance: $" + balance);
//            }
//            else
//            {
//                Console.WriteLine("Invalid option");
//            }
//        }
//    }

//}
