﻿//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Linq;
//using System.Runtime.Remoting.Lifetime;
//using System.Runtime.Remoting.Messaging;
//using System.Text;
//using System.Threading.Tasks;

//namespace BankingSystem
//{
//    internal class task5
//    {
//        static void Main()
//        {
//            Console.Write("Create your password: ");
//            string password = Console.ReadLine();

//            bool isValid = true;

//            if (password.Length < 8)
//            {
//                Console.WriteLine("Password must be at least 8 characters long.");
//                isValid = false;
//            }

//            bool hasUppercase = false;
//            foreach (char c in password)
//            {
//                if (char.IsUpper(c))
//                {
//                    hasUppercase = true;
//                    break;
//                }
//            }
//            if (!hasUppercase)
//            {
//                Console.WriteLine("Password must contain at least one uppercase letter.");
//                isValid = false;
//            }

//            bool hasDigit = false;
//            foreach (char c in password)
//            {
//                if (char.IsDigit(c))
//                {
//                    hasDigit = true;
//                    break;
//                }
//            }
//            if (!hasDigit)
//            {
//                Console.WriteLine("Password must contain at least one digit.");
//                isValid = false; gt
//            }

//            if (isValid)
//            {
//                Console.WriteLine("Password is valid.");
//            }
//            else
//            {
//                Console.WriteLine("Password is invalid.");
//            }
//        }
//    }
//}
