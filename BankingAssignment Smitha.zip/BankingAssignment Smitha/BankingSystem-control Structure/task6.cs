﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace BankingSystem
//{
//    internal class task6
//    {
//        static void Main()
//        {
//            string[] transactions = new string[100];  // fixed size array
//            int transactionCount = 0;
//            double balance = 0;

//            while (true)
//            {
//                Console.WriteLine("\n1. Deposit");
//                Console.WriteLine("2. Withdraw");
//                Console.WriteLine("3. Exit");
//                Console.Write("Enter choice: ");
//                int choice = int.Parse(Console.ReadLine());

//                if (choice == 1)
//                {
//                    Console.Write("Deposit amount: ");
//                    double amount = double.Parse(Console.ReadLine());
//                    balance += amount;
//                    transactions[transactionCount] = "Deposited: " + amount;
//                    transactionCount++;
//                }
//                else if (choice == 2)
//                {
//                    Console.Write("Withdraw amount: ");
//                    double amount = double.Parse(Console.ReadLine());
//                    if (amount <= balance)
//                    {
//                        balance -= amount;
//                        transactions[transactionCount] = "Withdrawn: " + amount;
//                        transactionCount++;
//                    }
//                    else
//                    {
//                        Console.WriteLine("Not enough balance");
//                    }
//                }
//                else if (choice == 3)
//                {
//                    break;
//                }
//                else
//                {
//                    Console.WriteLine("Invalid");
//                }
//            }

//            Console.WriteLine("\nTransaction History:");
//            for (int i = 0; i < transactionCount; i++)
//            {
//                Console.WriteLine(transactions[i]);
//            }
//            Console.WriteLine("Final Balance: " + balance);
//        }
//    }
//}

