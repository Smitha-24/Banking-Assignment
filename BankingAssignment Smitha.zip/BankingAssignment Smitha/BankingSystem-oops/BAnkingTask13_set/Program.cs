﻿using System;
using System.Collections.Generic;

class Customer
{
    public int CustomerId;
    public string FirstName;
    public string LastName;
    public string DOB;
    public string Email;
    public string PhoneNumber;
    public string Address;
}

class Account
{
    public int AccountId;
    public int CustomerId;
    public string AccountType;
    public double Balance;

    public override bool Equals(object obj)
    {
        return obj is Account acc && AccountId == acc.AccountId;
    }

    public override int GetHashCode()
    {
        return AccountId.GetHashCode();
    }
}

class Bank
{
    List<Customer> customers = new List<Customer>();
    HashSet<Account> accounts = new HashSet<Account>();

    int nextCustomerId = 1;
    int nextAccountId = 1001;

    public void CreateAccount(string firstName, string lastName, string dob, string email, string phone, string address, string accountType, double initialDeposit)
    {
        Customer customer = new Customer
        {
            CustomerId = nextCustomerId++,
            FirstName = firstName,
            LastName = lastName,
            DOB = dob,
            Email = email,
            PhoneNumber = phone,
            Address = address
        };
        customers.Add(customer);

        Account account = new Account
        {
            AccountId = nextAccountId++,
            CustomerId = customer.CustomerId,
            AccountType = accountType,
            Balance = initialDeposit
        };
        accounts.Add(account);

        Console.WriteLine($"Account Created: {account.AccountId} for {firstName} {lastName}");
    }

    public void ListAccounts()
    {
        foreach (var acc in accounts)
        {
            var cust = customers.Find(c => c.CustomerId == acc.CustomerId);
            Console.WriteLine($"AccountId: {acc.AccountId}, Name: {cust.FirstName}, Balance: ₹{acc.Balance}");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Bank bank = new Bank();
        bank.CreateAccount("Smitha", "S", "2000-06-01", "smitha@email.com", "9876543210", "Mangalore", "savings", 2000);
        bank.CreateAccount("Anu", "A", "2001-04-10", "anu@email.com", "9123456789", "Chennai", "current", 1500);

        bank.ListAccounts();

        Console.ReadLine();
    }
}
