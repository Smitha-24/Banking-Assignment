﻿using System;
using System.Collections.Generic;

// Exceptions
class InsufficientFundException : Exception { public InsufficientFundException(string message) : base(message) { } }
class InvalidAccountException : Exception { public InvalidAccountException(string message) : base(message) { } }
class OverDraftLimitExcededException : Exception { public OverDraftLimitExcededException(string message) : base(message) { } }

// Customer Class
class Customer
{
    public int CustomerId;
    public string FirstName;
    public string LastName;
    public string Email;
    public string PhoneNumber;
    public string Address;

    public void DisplayCustomer()
    {
        Console.WriteLine($"Customer ID: {CustomerId}");
        Console.WriteLine($"Name: {FirstName} {LastName}");
        Console.WriteLine($"Email: {Email}");
        Console.WriteLine($"Phone: {PhoneNumber}");
        Console.WriteLine($"Address: {Address}");
    }
}

// Abstract Account
abstract class Account
{
    private static long lastAccNo = 1000;
    public long AccountNumber;
    public string AccountType;
    public float AccountBalance;
    public Customer Customer;

    public Account(string accType, float balance, Customer customer)
    {
        AccountNumber = ++lastAccNo;
        AccountType = accType;
        AccountBalance = balance;
        Customer = customer;
    }

    public abstract void Withdraw(float amount);
}

// Subclasses
class SavingsAccount : Account
{
    public float InterestRate = 4.5f;
    public SavingsAccount(float balance, Customer customer)
        : base("Savings", balance >= 500 ? balance : 500, customer) { }
    public void CalculateInterest() { float interest = AccountBalance * (InterestRate / 100); AccountBalance += interest; }
    public override void Withdraw(float amount)
    {
        if (AccountBalance - amount >= 500) AccountBalance -= amount;
        else throw new InsufficientFundException("Cannot withdraw! Minimum balance 500 required.");
    }
}

class CurrentAccount : Account
{
    public float OverdraftLimit = 10000;
    public CurrentAccount(float balance, Customer customer)
        : base("Current", balance, customer) { }
    public override void Withdraw(float amount)
    {
        if (AccountBalance - amount >= -OverdraftLimit) AccountBalance -= amount;
        else throw new OverDraftLimitExcededException("Overdraft limit exceeded.");
    }
}

class ZeroBalanceAccount : Account
{
    public ZeroBalanceAccount(Customer customer) : base("ZeroBalance", 0, customer) { }
    public override void Withdraw(float amount)
    {
        if (AccountBalance >= amount) AccountBalance -= amount;
        else throw new InsufficientFundException("Insufficient balance.");
    }
}

// Bank class (using Dictionary)
class Bank
{
    private Dictionary<long, Account> accounts = new Dictionary<long, Account>();

    public void CreateAccount(Customer customer, string accType, float balance)
    {
        Account acc = null;
        if (accType == "Savings")
            acc = new SavingsAccount(balance, customer);
        else if (accType == "Current")
            acc = new CurrentAccount(balance, customer);
        else if (accType == "ZeroBalance")
            acc = new ZeroBalanceAccount(customer);

        if (acc != null)
        {
            if (!accounts.ContainsKey(acc.AccountNumber))
            {
                accounts.Add(acc.AccountNumber, acc);
                Console.WriteLine($"Account created successfully! Account No: {acc.AccountNumber}");
            }
            else
                Console.WriteLine("Account already exists!");
        }
    }

    private Account FindAccount(long accNo)
    {
        if (accounts.ContainsKey(accNo))
            return accounts[accNo];
        throw new InvalidAccountException("Account not found.");
    }

    public void Deposit(long accNo, float amount)
    {
        Account acc = FindAccount(accNo);
        acc.AccountBalance += amount;
        Console.WriteLine("Deposit successful. New Balance: " + acc.AccountBalance);
    }

    public void Withdraw(long accNo, float amount)
    {
        Account acc = FindAccount(accNo);
        acc.Withdraw(amount);
        Console.WriteLine("After Withdraw Balance: " + acc.AccountBalance);
    }

    public void GetBalance(long accNo)
    {
        Account acc = FindAccount(accNo);
        Console.WriteLine("Balance: " + acc.AccountBalance);
    }

    public void GetAccountDetails(long accNo)
    {
        Account acc = FindAccount(accNo);
        Console.WriteLine($"Account No: {acc.AccountNumber} | Type: {acc.AccountType} | Balance: {acc.AccountBalance}");
        acc.Customer.DisplayCustomer();
    }

    public void CalculateInterest()
    {
        foreach (var acc in accounts.Values)
        {
            if (acc is SavingsAccount sa)
            {
                sa.CalculateInterest();
                Console.WriteLine($"Interest applied for Account No: {sa.AccountNumber}");
            }
        }
    }

    public void Transfer(long fromAccNo, long toAccNo, float amount)
    {
        Account fromAcc = FindAccount(fromAccNo);
        Account toAcc = FindAccount(toAccNo);
        fromAcc.Withdraw(amount);
        toAcc.AccountBalance += amount;
        Console.WriteLine("Transfer successful.");
    }

    public void ListAccounts()
    {
        Console.WriteLine("\nAll Accounts (Sorted by Customer Name):");
        var sorted = new List<Account>(accounts.Values);
        sorted.Sort((a, b) => string.Compare(a.Customer.FirstName, b.Customer.FirstName));
        foreach (var acc in sorted)
        {
            Console.WriteLine($"Account No: {acc.AccountNumber} | Name: {acc.Customer.FirstName} | Balance: {acc.AccountBalance}");
        }
    }
}

// Main Program
internal class Program
{
    static void Main()
    {
        Bank bank = new Bank();

        while (true)
        {
            try
            {
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Create Account");
                Console.WriteLine("2. Deposit");
                Console.WriteLine("3. Withdraw");
                Console.WriteLine("4. Get Balance");
                Console.WriteLine("5. Get Account Details");
                Console.WriteLine("6. Calculate Interest");
                Console.WriteLine("7. Transfer");
                Console.WriteLine("8. List All Accounts");
                Console.WriteLine("9. Exit");
                Console.Write("Enter your choice: ");
                int choice = int.Parse(Console.ReadLine());

                if (choice == 1)
                {
                    Customer customer = new Customer();
                    Console.Write("Customer ID: ");
                    customer.CustomerId = int.Parse(Console.ReadLine());
                    Console.Write("First Name: ");
                    customer.FirstName = Console.ReadLine();
                    Console.Write("Last Name: ");
                    customer.LastName = Console.ReadLine();
                    Console.Write("Email: ");
                    customer.Email = Console.ReadLine();
                    Console.Write("Phone: ");
                    customer.PhoneNumber = Console.ReadLine();
                    Console.Write("Address: ");
                    customer.Address = Console.ReadLine();

                    Console.Write("Account Type (Savings/Current/ZeroBalance): ");
                    string accType = Console.ReadLine();
                    float balance = 0;
                    if (accType != "ZeroBalance")
                    {
                        Console.Write("Initial Balance: ");
                        balance = float.Parse(Console.ReadLine());
                    }
                    bank.CreateAccount(customer, accType, balance);
                }
                else if (choice == 2)
                {
                    Console.Write("Account No: ");
                    long accNo = long.Parse(Console.ReadLine());
                    Console.Write("Deposit Amount: ");
                    float amount = float.Parse(Console.ReadLine());
                    bank.Deposit(accNo, amount);
                }
                else if (choice == 3)
                {
                    Console.Write("Account No: ");
                    long accNo = long.Parse(Console.ReadLine());
                    Console.Write("Withdraw Amount: ");
                    float amount = float.Parse(Console.ReadLine());
                    bank.Withdraw(accNo, amount);
                }
                else if (choice == 4)
                {
                    Console.Write("Account No: ");
                    long accNo = long.Parse(Console.ReadLine());
                    bank.GetBalance(accNo);
                }
                else if (choice == 5)
                {
                    Console.Write("Account No: ");
                    long accNo = long.Parse(Console.ReadLine());
                    bank.GetAccountDetails(accNo);
                }
                else if (choice == 6)
                {
                    bank.CalculateInterest();
                }
                else if (choice == 7)
                {
                    Console.Write("From Account No: ");
                    long fromAcc = long.Parse(Console.ReadLine());
                    Console.Write("To Account No: ");
                    long toAcc = long.Parse(Console.ReadLine());
                    Console.Write("Transfer Amount: ");
                    float amount = float.Parse(Console.ReadLine());
                    bank.Transfer(fromAcc, toAcc, amount);
                }
                else if (choice == 8)
                {
                    bank.ListAccounts();
                }
                else if (choice == 9)
                {
                    Console.WriteLine("Exiting...");
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid choice.");
                }
            }
            catch (InvalidAccountException ex) { Console.WriteLine("Error: " + ex.Message); }
            catch (InsufficientFundException ex) { Console.WriteLine("Error: " + ex.Message); }
            catch (OverDraftLimitExcededException ex) { Console.WriteLine("Error: " + ex.Message); }
            catch (Exception ex) { Console.WriteLine("Error: " + ex.Message); }
        }
    }
}
