﻿using System;

public abstract class BankAccount
{
    protected int accountNumber;
    protected string customerName;
    protected double balance;

    public BankAccount() { }

    public BankAccount(int accountNumber, string customerName, double balance)
    {
        this.accountNumber = accountNumber;
        this.customerName = customerName;
        this.balance = balance;
    }

    public void DisplayAccountInfo()
    {
        Console.WriteLine("\nAccount Number: " + accountNumber);
        Console.WriteLine("Customer Name: " + customerName);
        Console.WriteLine("Account Balance: " + balance);
    }

    // Abstract Methods
    public abstract void Deposit(float amount);
    public abstract void Withdraw(float amount);
    public abstract void CalculateInterest();
}
