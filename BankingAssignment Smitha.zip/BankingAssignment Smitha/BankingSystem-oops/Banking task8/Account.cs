﻿using System;

public class Account
{
    protected int accountNumber;
    protected string accountType;
    protected double accountBalance;

    public Account(int accountNumber, string accountType, double accountBalance)
    {
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.accountBalance = accountBalance;
    }

    // Overloaded Deposit Methods
    public void Deposit(int amount)
    {
        Deposit((double)amount);
    }

    public void Deposit(float amount)
    {
        Deposit((double)amount);
    }

    public void Deposit(double amount)
    {
        if (amount > 0)
        {
            accountBalance += amount;
            Console.WriteLine("Deposited: " + amount);
        }
        else
        {
            Console.WriteLine("Invalid deposit amount.");
        }
    }

    // Overloaded Withdraw Methods
    public virtual void Withdraw(int amount)
    {
        Withdraw((double)amount);
    }

    public virtual void Withdraw(float amount)
    {
        Withdraw((double)amount);
    }

    public virtual void Withdraw(double amount)
    {
        if (amount <= accountBalance)
        {
            accountBalance -= amount;
            Console.WriteLine("Withdrawn: " + amount);
        }
        else
        {
            Console.WriteLine("Insufficient balance.");
        }
    }

    public virtual void CalculateInterest()
    {
        Console.WriteLine("No interest for base account.");
    }

    public void DisplayAccountInfo()
    {
        Console.WriteLine("Account Number: " + accountNumber);
        Console.WriteLine("Account Type: " + accountType);
        Console.WriteLine("Account Balance: " + accountBalance);
    }
}
