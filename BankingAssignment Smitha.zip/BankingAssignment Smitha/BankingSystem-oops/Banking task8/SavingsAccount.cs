﻿using System;

public class SavingsAccount : Account
{
    private double interestRate;

    public SavingsAccount(int accountNumber, double accountBalance, double interestRate)
        : base(accountNumber, "Savings", accountBalance)
    {
        this.interestRate = interestRate;
    }

    public override void CalculateInterest()
    {
        double interest = accountBalance * interestRate / 100;
        accountBalance += interest;
        Console.WriteLine("Interest added: " + interest);
    }
}
