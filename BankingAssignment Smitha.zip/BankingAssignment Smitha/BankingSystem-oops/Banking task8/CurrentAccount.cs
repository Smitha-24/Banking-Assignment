﻿using System;

public class CurrentAccount : Account
{
    private const double overdraftLimit = 5000;

    public CurrentAccount(int accountNumber, double accountBalance)
        : base(accountNumber, "Current", accountBalance)
    {
    }

    public override void Withdraw(double amount)
    {
        if (accountBalance + overdraftLimit >= amount)
        {
            accountBalance -= amount;
            Console.WriteLine("Withdrawn: " + amount);
        }
        else
        {
            Console.WriteLine("Cannot withdraw. Overdraft limit exceeded.");
        }
    }

    public override void CalculateInterest()
    {
        Console.WriteLine("No interest for current account.");
    }
}
