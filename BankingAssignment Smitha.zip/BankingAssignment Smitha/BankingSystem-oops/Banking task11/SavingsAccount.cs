﻿using System;

public class SavingsAccount : Account
{
    public float InterestRate = 4.5f;

    public SavingsAccount(float balance, Customer customer)
        : base("Savings", balance >= 500 ? balance : 500, customer) { }

    public void CalculateInterest()
    {
        float interest = AccountBalance * (InterestRate / 100);
        AccountBalance += interest;
    }

    public override void Withdraw(float amount)
    {
        if (AccountBalance - amount >= 500)
            AccountBalance -= amount;
        else
            Console.WriteLine("Cannot withdraw! Minimum balance 500 required.");
    }
}
