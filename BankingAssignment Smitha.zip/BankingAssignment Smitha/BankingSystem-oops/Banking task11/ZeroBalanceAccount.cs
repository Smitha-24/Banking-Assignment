﻿using System;

public class ZeroBalanceAccount : Account
{
    public ZeroBalanceAccount(Customer customer)
        : base("ZeroBalance", 0, customer) { }

    public override void Withdraw(float amount)
    {
        if (AccountBalance >= amount)
            AccountBalance -= amount;
        else
            Console.WriteLine("Insufficient balance!");
    }
}
