﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Bank bank = new Bank();

        while (true)
        {
            Console.WriteLine("\n1. Create Account\n2. Deposit\n3. Withdraw\n4. Get Balance\n5. Get Account Details\n6. Calculate Interest\n7. Exit");
            Console.Write("Enter your choice: ");
            int choice = int.Parse(Console.ReadLine());

            if (choice == 1)
            {
                Customer customer = new Customer();
                Console.Write("Customer ID: ");
                customer.CustomerId = int.Parse(Console.ReadLine());
                Console.Write("First Name: ");
                customer.FirstName = Console.ReadLine();
                Console.Write("Last Name: ");
                customer.LastName = Console.ReadLine();
                Console.Write("Email: ");
                customer.EmailAddress = Console.ReadLine();
                Console.Write("Phone: ");
                customer.PhoneNumber = Console.ReadLine();
                Console.Write("Address: ");
                customer.Address = Console.ReadLine();

                Console.Write("Account Type (Savings/Current/ZeroBalance): ");
                string accType = Console.ReadLine();

                float balance = 0;
                if (accType != "ZeroBalance")
                {
                    Console.Write("Initial Balance: ");
                    balance = float.Parse(Console.ReadLine());
                }

                bank.CreateAccount(customer, accType, balance);
            }
            else if (choice == 2)
            {
                Console.Write("Account No: ");
                long accNo = long.Parse(Console.ReadLine());
                Console.Write("Deposit Amount: ");
                float amount = float.Parse(Console.ReadLine());
                bank.Deposit(accNo, amount);
            }
            else if (choice == 3)
            {
                Console.Write("Account No: ");
                long accNo = long.Parse(Console.ReadLine());
                Console.Write("Withdraw Amount: ");
                float amount = float.Parse(Console.ReadLine());
                bank.Withdraw(accNo, amount);
            }
            else if (choice == 4)
            {
                Console.Write("Account No: ");
                long accNo = long.Parse(Console.ReadLine());
                bank.GetBalance(accNo);
            }
            else if (choice == 5)
            {
                Console.Write("Account No: ");
                long accNo = long.Parse(Console.ReadLine());
                bank.GetAccountDetails(accNo);
            }
            else if (choice == 6)
            {
                bank.CalculateInterest();
            }
            else if (choice == 7)
            {
                Console.WriteLine("Exiting...");
                break;
            }
            else
            {
                Console.WriteLine("Invalid choice.");
            }
        }
    }
}
