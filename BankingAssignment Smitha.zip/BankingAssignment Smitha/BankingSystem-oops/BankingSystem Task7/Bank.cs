﻿using System;

namespace BankingSystem
{
    public class Customer
    {
        private int customerId;
        private string firstName;
        private string lastName;
        private string emailAddress;
        private string phoneNumber;
        private string address;

        public Customer() { }

        public Customer(int customerId, string firstName, string lastName, string emailAddress, string phoneNumber, string address)
        {
            this.customerId = customerId;
            this.firstName = firstName;
            this.lastName = lastName;
            this.emailAddress = emailAddress;
            this.phoneNumber = phoneNumber;
            this.address = address;
        }

        public int CustomerId
        {
            get 
            { 
                return customerId;
            }
            set
            {
                customerId = value;
            }
        }

        public string FirstName
        {
            get 
            { 
                return firstName; 
            }
            set 
            {
                firstName = value; 
            }
        }

        public string LastName
        {
            get 
            { 
                return lastName;
            }
            set 
            {
                lastName = value;
            }
        }

        public string EmailAddress
        {
            get
            {
                return emailAddress;
            }
            set 
            { 
                emailAddress = value; 
            }
        }

        public string PhoneNumber
        {
            get
            { 
                return phoneNumber;
            }
            set 
            { 
                phoneNumber = value;
            }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        public void DisplayCustomerInfo()
        {
            Console.WriteLine("---- Customer Details ----");
            Console.WriteLine("Customer ID: " + customerId);
            Console.WriteLine("Name: " + firstName + " " + lastName);
            Console.WriteLine("Email: " + emailAddress);
            Console.WriteLine("Phone: " + phoneNumber);
            Console.WriteLine("Address: " + address);
        }
    }

    public class Account
    {
        private int accountNumber;
        private string accountType;
        private double accountBalance;

        public Account() { }

        public Account(int accountNumber, string accountType, double accountBalance)
        {
            this.accountNumber = accountNumber;
            this.accountType = accountType;
            this.accountBalance = accountBalance;
        }

        public int AccountNumber
        {
            get 
            {
                return accountNumber; 
            }
            set 
            { 
                accountNumber = value; 
            }
        }

        public string AccountType
        {
            get 
            {
                return accountType;
            }
            set
            {
                accountType = value;
            }
        }

        public double AccountBalance
        {
            get 
            { 
                return accountBalance; 
            }
            set
            { 
                accountBalance = value; 
            }
        }

        public void Deposit(double amount)
        {
            if (amount > 0)
            {
                accountBalance += amount;
                Console.WriteLine($"Deposited: {amount}. New Balance: {accountBalance}");
            }
            else
            {
                Console.WriteLine("Invalid deposit amount.");
            }
        }

        public void Withdraw(double amount)
        {
            if (amount <= accountBalance)
            {
                accountBalance -= amount;
                Console.WriteLine($"Withdrawn: {amount}. Remaining Balance: {accountBalance}");
            }
            else
            {
                Console.WriteLine("Insufficient balance.");
            }
        }

        public void CalculateInterest()
        {
            if (accountType.ToLower() == "savings")
            {
                double interest = accountBalance * 0.045;
                accountBalance += interest;
                Console.WriteLine($"Interest added: {interest}. New Balance: {accountBalance}");
            }
            else
            {
                Console.WriteLine("Interest is only for Savings account.");
            }
        }

        public void DisplayAccountInfo()
        {
            Console.WriteLine("---- Account Details ----");
            Console.WriteLine("Account Number: " + accountNumber);
            Console.WriteLine("Account Type: " + accountType);
            Console.WriteLine("Account Balance: " + accountBalance);
        }
    }

    class Bank
    {
        static void Main(string[] args)
        {
            // Getting Customer details
            Console.WriteLine("Enter Customer Details:");
            Console.Write("Customer ID: ");
            int custId = int.Parse(Console.ReadLine());

            Console.Write("First Name: ");
            string fname = Console.ReadLine();

            Console.Write("Last Name: ");
            string lname = Console.ReadLine();

            Console.Write("Email Address: ");
            string email = Console.ReadLine();

            Console.Write("Phone Number: ");
            string phone = Console.ReadLine();

            Console.Write("Address: ");
            string addr = Console.ReadLine();

            Customer customer = new Customer(custId, fname, lname, email, phone, addr);
            customer.DisplayCustomerInfo();

            // Getting Account details
            Console.WriteLine("\nEnter Account Details:");
            Console.Write("Account Number: ");
            int accNo = int.Parse(Console.ReadLine());

            Console.Write("Account Type (Savings/Current): ");
            string accType = Console.ReadLine();

            Console.Write("Initial Balance: ");
            double balance = double.Parse(Console.ReadLine());

            Account account = new Account(accNo, accType, balance);
            account.DisplayAccountInfo();

            // Performing deposit
            Console.Write("\nEnter amount to deposit: ");
            double depAmount = double.Parse(Console.ReadLine());
            account.Deposit(depAmount);

            // Performing withdraw
            Console.Write("\nEnter amount to withdraw: ");
            double withAmount = double.Parse(Console.ReadLine());
            account.Withdraw(withAmount);

            // Calculating Interest
            Console.WriteLine("\nCalculating Interest (only for Savings account)");
            account.CalculateInterest();

            // Final Account Info
            Console.WriteLine("\n---- Final Account Details ----");
            account.DisplayAccountInfo();

            Console.ReadLine();
        }
    }
}
