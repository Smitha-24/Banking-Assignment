﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking_Task10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Bank bank = new Bank();

            while (true)
            {
                Console.WriteLine("\n1. Create Account\n2. Deposit\n3. Withdraw\n4. Transfer\n5. Get Balance\n6. Get Account Details\n7. Exit");
                Console.Write("Enter your choice: ");
                int choice = int.Parse(Console.ReadLine());

                if (choice == 1)
                {
                    Console.Write("Customer ID: ");
                    int id = int.Parse(Console.ReadLine());
                    Console.Write("First Name: ");
                    string fname = Console.ReadLine();
                    Console.Write("Last Name: ");
                    string lname = Console.ReadLine();
                    Console.Write("Email: ");
                    string email = Console.ReadLine();
                    Console.Write("Phone: ");
                    string phone = Console.ReadLine();
                    Console.Write("Address: ");
                    string address = Console.ReadLine();

                    Customer cust = new Customer(id, fname, lname, email, phone, address);

                    Console.Write("Account Type: ");
                    string type = Console.ReadLine();
                    Console.Write("Initial Balance: ");
                    float bal = float.Parse(Console.ReadLine());

                    bank.CreateAccount(cust, type, bal);
                }
                else if (choice == 2)
                {
                    Console.Write("Account Number: ");
                    long acc = long.Parse(Console.ReadLine());
                    Console.Write("Deposit Amount: ");
                    float amt = float.Parse(Console.ReadLine());
                    Console.WriteLine("New Balance: " + bank.Deposit(acc, amt));
                }
                else if (choice == 3)
                {
                    Console.Write("Account Number: ");
                    long acc = long.Parse(Console.ReadLine());
                    Console.Write("Withdraw Amount: ");
                    float amt = float.Parse(Console.ReadLine());
                    Console.WriteLine("New Balance: " + bank.Withdraw(acc, amt));
                }
                else if (choice == 4)
                {
                    Console.Write("From Account: ");
                    long from = long.Parse(Console.ReadLine());
                    Console.Write("To Account: ");
                    long to = long.Parse(Console.ReadLine());
                    Console.Write("Amount: ");
                    float amt = float.Parse(Console.ReadLine());
                    bank.Transfer(from, to, amt);
                }
                else if (choice == 5)
                {
                    Console.Write("Account Number: ");
                    long acc = long.Parse(Console.ReadLine());
                    Console.WriteLine("Balance: " + bank.GetBalance(acc));
                }
                else if (choice == 6)
                {
                    Console.Write("Account Number: ");
                    long acc = long.Parse(Console.ReadLine());
                    bank.GetAccountDetails(acc);
                }
                else if (choice == 7)
                {
                    Console.WriteLine("Exiting...");
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid choice.");
                }
            }
        }
    }


}



